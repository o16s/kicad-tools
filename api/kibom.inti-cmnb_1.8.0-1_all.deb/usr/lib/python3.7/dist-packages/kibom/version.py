# -*- coding: utf-8 -*-

KIBOM_VERSION = "1.8.0"
